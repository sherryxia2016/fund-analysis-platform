# A股场外基金分析平台 - 部署指南

## 📦 文件说明

- `fund_analysis_package.tar.gz` - 完整的项目代码包
- 解压后包含：`data/`、`frontend/`、`scripts/`、`docs/` 四个目录

---

## 🚀 快速部署（5步完成）

### 第1步：解压项目包

```bash
tar -xzvf fund_analysis_package.tar.gz
cd fund_analysis_package
```

### 第2步：安装Python依赖

```bash
pip install akshare pandas numpy
```

### 第3步：获取最新基金数据

```bash
cd scripts
python fetch_fund_data.py
# 运行时间约10-15分钟
cd ..
```

### 第4步：安装前端依赖并启动

```bash
cd frontend
npm install

# 复制数据到前端
mkdir -p public/data
cp ../data/* public/data/

# 启动开发服务器
npm run dev
```

访问 http://localhost:5173 即可查看网站

### 第5步：构建生产版本

```bash
npm run build
# 构建输出在 dist/ 目录
```

---

## 📋 详细说明

### 环境要求

| 软件 | 版本 |
|------|------|
| Python | 3.8+ |
| Node.js | 18+ |
| npm | 8+ |

### 项目结构

```
fund_analysis_package/
├── data/                    # 数据文件（CSV/JSON）
│   ├── fund_info_with_prob.csv      # 基金信息
│   ├── fund_nav_data.json           # 净值数据
│   ├── sector_indices.json          # 板块指数
│   ├── primary_sector_indices.json  # 一级板块指数
│   ├── sector_top5.json             # Top5基金
│   └── profit_probability.json      # 盈利概率
├── frontend/                # React前端
│   ├── src/
│   │   ├── components/ui/   # UI组件
│   │   ├── sections/        # 页面组件
│   │   ├── hooks/           # 自定义Hooks
│   │   └── types/           # TypeScript类型
│   ├── package.json         # 依赖配置
│   └── index.html           # 入口HTML
├── scripts/                 # Python脚本
│   └── fetch_fund_data.py   # 数据获取脚本
└── docs/                    # 文档
    └── DEPLOYMENT_GUIDE.md  # 详细部署指南
```

### 数据更新

前端已内置自动刷新机制（每5分钟），如需手动更新：

```bash
cd scripts
python fetch_fund_data.py
cp ../data/* ../frontend/public/data/
```

### 部署到生产服务器

```bash
# 构建生产版本
cd frontend
npm run build

# 部署dist目录到Web服务器
# Nginx示例:
sudo cp -r dist/* /var/www/html/
```

---

## 🔧 常见问题

### Q1: Python脚本运行失败？
```bash
# 升级akshare
pip install --upgrade akshare
```

### Q2: npm install失败？
```bash
# 使用淘宝镜像
npm config set registry https://registry.npmmirror.com
npm install
```

### Q3: 数据文件找不到？
```bash
# 确保数据在正确位置
ls frontend/public/data/
# 应该有6个文件
```

---

## 📞 技术支持

详细文档请查看 `docs/DEPLOYMENT_GUIDE.md`
